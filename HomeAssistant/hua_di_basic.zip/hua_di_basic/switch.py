from __future__ import annotations

from homeassistant.components.switch import SwitchEntity
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN, DISPLAY_DEVICE_NAME
from .coordinator import HuaDiCoordinator


class HuaDiPowerSwitch(CoordinatorEntity[HuaDiCoordinator], SwitchEntity):
    _attr_has_entity_name = True
    _attr_name = "电源"
    _attr_icon = "mdi:power"

    def __init__(self, coordinator: HuaDiCoordinator) -> None:
        super().__init__(coordinator)
        self._attr_unique_id = f"{coordinator.device_id}_power"
        self._attr_device_info = {
            "identifiers": {(DOMAIN, coordinator.device_id)},
            "name": DISPLAY_DEVICE_NAME,
            "manufacturer": "Vatti / HuaDi",
            "model": "Water Heater",
        }

    @property
    def is_on(self):
        return str((self.coordinator.data or {}).get("powerStat")) == "1"

    async def async_turn_on(self, **kwargs) -> None:
        await self.coordinator.async_set_power(True)

    async def async_turn_off(self, **kwargs) -> None:
        await self.coordinator.async_set_power(False)


async def async_setup_entry(hass, entry, async_add_entities):
    coordinator: HuaDiCoordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([HuaDiPowerSwitch(coordinator)])
