from homeassistant.const import Platform

DOMAIN = "hua_di_basic"
DEFAULT_NAME = "热水器"
DISPLAY_DEVICE_NAME = "华帝热水器"
CONF_PHONE = "phone"
CONF_TOKEN = "token"
CONF_ACCESS_KEY_ID = "access_key_id"
CONF_ACCESS_KEY_SECRET = "access_key_secret"
CONF_DEVICE_ID = "device_id"
CONF_PRODUCT_KEY = "product_key"
CONF_ACW_TC = "acw_tc"
CONF_ENV_PATH = "env_path"

DEFAULT_ACCESS_KEY_ID = "7ecce3d396113fdf378ee08594919aa9"
DEFAULT_ACCESS_KEY_SECRET = "6c9d8dbf2ae6031569fefd302b1a1519"

# The ECM statistics client uses the same credentials as the app API unless
# a deployment supplies dedicated ECM credentials in the entry data.  Keep
# these names explicit because api.py imports them when the integration loads.
ECM_ACCESS_KEY_ID = DEFAULT_ACCESS_KEY_ID
ECM_ACCESS_KEY_SECRET = DEFAULT_ACCESS_KEY_SECRET

PLATFORMS = [Platform.CLIMATE, Platform.SENSOR, Platform.SWITCH]
