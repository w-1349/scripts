from __future__ import annotations

import logging
import time
from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant

from .api import HuaDiApi, normalize_temp
from .const import CONF_PHONE, DOMAIN

_LOGGER = logging.getLogger(__name__)


def _mask_value(value: object, keep: int = 4) -> str:
    text = str(value or "")
    if not text:
        return ""
    if len(text) <= keep:
        return "*" * len(text)
    return f"****{text[-keep:]}"


def _mask_phone(phone: object) -> str:
    text = str(phone or "")
    if len(text) <= 7:
        return "****" if text else ""
    return f"{text[:3]}****{text[-4:]}"


def _mask_topic(topic: str) -> str:
    parts = str(topic or "").split("/")
    if len(parts) >= 3:
        parts[-2] = _mask_value(parts[-2])
        parts[-1] = _mask_phone(parts[-1])
    return "/".join(parts)


class HuaDiCoordinator:
    """Runtime state for the retained MQTT status and two monthly sensors."""

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry, api: HuaDiApi) -> None:
        self.hass = hass
        self.entry = entry
        self.api = api
        self.data: dict[str, Any] = {}
        self.last_update_success = True
        self._listeners: list[tuple[callable, object | None]] = []
        env = self.api.load_env()
        self.device_id = env.get("DEVICE_ID", entry.entry_id)
        self.phone = str(entry.data.get(CONF_PHONE) or "")
        self._mqtt = None

    def async_add_listener(self, update_callback, context=None):
        listener = (update_callback, context)
        self._listeners.append(listener)

        def remove_listener() -> None:
            try:
                self._listeners.remove(listener)
            except ValueError:
                pass

        return remove_listener

    def async_set_updated_data(self, data: dict[str, Any]) -> None:
        self.data = data
        for callback, _context in list(self._listeners):
            callback()

    def _merge_push_data(self, pushed: dict[str, Any], source: str = "mqtt") -> dict[str, Any]:
        data = dict(self.data or {})
        if source == "mqtt":
            pushed.setdefault("device_status", 1)
            pushed.setdefault("device_status_desc", "在线")
            pushed["device_last_seen_time"] = int(time.time())
        data.update(pushed)
        return data

    async def async_start(self) -> None:
        if not self.phone:
            self.async_set_updated_data({"mqtt_connected": False, "mqtt_error": "missing_phone"})
            return

        self.async_set_updated_data({
            "mqtt_connected": False,
            "mqtt_topic": _mask_topic(f"deviceProperty/{self.device_id}/{self.phone}"),
        })

        def on_payload(payload: dict[str, Any]) -> None:
            self.hass.loop.call_soon_threadsafe(
                self.async_set_updated_data,
                self._merge_push_data(payload, source="mqtt"),
            )

        def on_connected(connected: bool, error: str | None) -> None:
            self.hass.loop.call_soon_threadsafe(
                self.async_set_updated_data,
                self._merge_push_data({"mqtt_connected": connected, "mqtt_error": error}, source="status"),
            )

        try:
            from .mqtt_client import HuaDiAppMqttClient
            self._mqtt = HuaDiAppMqttClient(
                device_id=self.device_id,
                phone=self.phone,
                on_payload=on_payload,
                on_connected=on_connected,
            )
            self._mqtt.start()
        except Exception as exc:  # noqa: BLE001
            _LOGGER.exception("HuaDi App MQTT start failed")
            self.async_set_updated_data({"mqtt_connected": False, "mqtt_error": str(exc)})

        self.hass.loop.create_task(self.async_load_monthly_statistics())

    async def async_load_monthly_statistics(self) -> None:
        """Load current-month water and gas once when the integration starts."""
        try:
            stats = await self.api.async_get_water_gas_statistics()
        except Exception as exc:  # noqa: BLE001
            _LOGGER.debug("HuaDi monthly statistics load failed: %s", exc)
            self.async_set_updated_data(self._merge_push_data({"stats_error": str(exc)}, source="statistics"))
            return
        self.async_set_updated_data(self._merge_push_data(stats, source="statistics"))

    async def async_stop(self) -> None:
        if self._mqtt:
            self._mqtt.stop()
            self._mqtt = None

    async def async_set_temperature(self, temperature: int) -> None:
        await self.api.async_control("temp", normalize_temp(temperature))

    async def async_set_power(self, on: bool) -> None:
        await self.api.async_control("on" if on else "off")
