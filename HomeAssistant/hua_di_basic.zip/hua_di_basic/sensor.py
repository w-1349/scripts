from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from homeassistant.components.sensor import SensorEntity, SensorEntityDescription, SensorStateClass
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN, DISPLAY_DEVICE_NAME
from .coordinator import HuaDiCoordinator


@dataclass(frozen=True, kw_only=True)
class MonthlySensorDescription(SensorEntityDescription):
    source_key: str
    value_fn: Callable[[dict[str, Any]], Any]


def _num2(key: str):
    def value(data):
        try:
            raw = data.get(key)
            if raw in (None, "", "unknown", "unavailable"):
                return None
            return round(float(raw), 2)
        except (TypeError, ValueError):
            return None
    return value


def _water_ton(key: str):
    def value(data):
        try:
            raw = data.get(key)
            if raw in (None, "", "unknown", "unavailable"):
                return None
            return round(float(raw) / 1000, 2)
        except (TypeError, ValueError):
            return None
    return value


SENSORS: tuple[MonthlySensorDescription, ...] = (
    MonthlySensorDescription(key="water_month", source_key="water_month", name="本月用水", native_unit_of_measurement="吨", state_class=SensorStateClass.TOTAL, value_fn=_water_ton("water_month")),
    MonthlySensorDescription(key="gas_month", source_key="gas_month", name="本月用气", native_unit_of_measurement="m³", state_class=SensorStateClass.TOTAL, value_fn=_num2("gas_month")),
)


class HuaDiMonthlySensor(CoordinatorEntity[HuaDiCoordinator], SensorEntity):
    _attr_has_entity_name = True

    def __init__(self, coordinator: HuaDiCoordinator, description: MonthlySensorDescription) -> None:
        super().__init__(coordinator)
        self.entity_description = description
        self._attr_unique_id = f"{coordinator.device_id}_{description.key}"
        self._attr_device_info = {
            "identifiers": {(DOMAIN, coordinator.device_id)},
            "name": DISPLAY_DEVICE_NAME,
            "manufacturer": "Vatti / HuaDi",
            "model": "Water Heater",
        }

    @property
    def native_value(self):
        return self.entity_description.value_fn(self.coordinator.data or {})


async def async_setup_entry(hass, entry, async_add_entities):
    coordinator: HuaDiCoordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([HuaDiMonthlySensor(coordinator, desc) for desc in SENSORS])
