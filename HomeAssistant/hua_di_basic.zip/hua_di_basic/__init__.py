from __future__ import annotations

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers import entity_registry as er

from .api import HuaDiApi
from .const import DOMAIN, PLATFORMS
from .coordinator import HuaDiCoordinator


REMOVED_ENTITY_KEYS = {
    "ai_wash", "qidian", "eco_wash", "temperature_mode", "set_temperature_number",
    "refresh_statistics", "power_status", "function_status", "device_work_status",
    "device_online_status", "set_temperature_display", "inlet_temperature",
    "outlet_temperature", "water_flow", "wifi_rssi", "water_year", "gas_year",
    "water_week", "gas_week", "daily_water", "daily_gas", "weekly_gas_total",
}


def _cleanup_removed_entities(hass: HomeAssistant, entry: ConfigEntry, coordinator: HuaDiCoordinator) -> None:
    registry = er.async_get(hass)
    for entity in list(er.async_entries_for_config_entry(registry, entry.entry_id)):
        if any(entity.unique_id == f"{coordinator.device_id}_{key}" for key in REMOVED_ENTITY_KEYS):
            registry.async_remove(entity.entity_id)


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    session = async_get_clientsession(hass)
    api = HuaDiApi(session, entry.data)
    coordinator = HuaDiCoordinator(hass, entry, api)

    hass.data.setdefault(DOMAIN, {})[entry.entry_id] = coordinator

    _cleanup_removed_entities(hass, entry, coordinator)

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    await coordinator.async_start()

    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    coordinator = hass.data.get(DOMAIN, {}).get(entry.entry_id)
    if coordinator:
        await coordinator.async_stop()

    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unload_ok:
        hass.data[DOMAIN].pop(entry.entry_id, None)
    return unload_ok
