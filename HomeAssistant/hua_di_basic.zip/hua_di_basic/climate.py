from __future__ import annotations

from homeassistant.components.climate import ClimateEntity
from homeassistant.components.climate.const import HVACMode, ClimateEntityFeature
from homeassistant.const import UnitOfTemperature
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .api import to_int
from .const import DEFAULT_NAME, DISPLAY_DEVICE_NAME, DOMAIN
from .coordinator import HuaDiCoordinator


class HuaDiClimate(CoordinatorEntity[HuaDiCoordinator], ClimateEntity):
    _attr_has_entity_name = False
    _attr_temperature_unit = UnitOfTemperature.CELSIUS
    _attr_min_temp = 35
    _attr_max_temp = 60
    _attr_target_temperature_step = 1
    _attr_hvac_modes = [HVACMode.OFF, HVACMode.HEAT]
    _attr_supported_features = ClimateEntityFeature.TARGET_TEMPERATURE

    def __init__(self, coordinator: HuaDiCoordinator) -> None:
        super().__init__(coordinator)
        device_id = coordinator.device_id
        self._attr_name = DEFAULT_NAME
        self._attr_unique_id = f"{device_id}_climate"
        self._attr_device_info = {
            "identifiers": {(DOMAIN, device_id)},
            "name": DISPLAY_DEVICE_NAME,
            "manufacturer": "Vatti / HuaDi",
            "model": "Water Heater",
        }

    @property
    def hvac_mode(self):
        return HVACMode.HEAT if str((self.coordinator.data or {}).get("powerStat")) == "1" else HVACMode.OFF

    @property
    def target_temperature(self):
        value = to_int((self.coordinator.data or {}).get("heater_temp"))
        return value if value is not None else 40

    @property
    def current_temperature(self):
        """Expose target temperature as current temperature for HomeKit display.

        HomeKit thermostat tiles show `current_temperature` as the large number.
        A water heater should not display inlet/outlet water temperature there,
        so keep the large HomeKit number aligned with the configured setpoint.
        Real inlet/outlet temperatures are still exposed as separate sensors.
        """
        return self.target_temperature

    async def async_set_temperature(self, **kwargs) -> None:
        temperature = kwargs.get("temperature")
        if temperature is None:
            return
        await self.coordinator.async_set_temperature(int(float(temperature)))

    async def async_set_hvac_mode(self, hvac_mode) -> None:
        if hvac_mode == HVACMode.HEAT:
            await self.coordinator.async_set_power(True)
        elif hvac_mode == HVACMode.OFF:
            await self.coordinator.async_set_power(False)


async def async_setup_entry(hass, entry, async_add_entities):
    coordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([HuaDiClimate(coordinator)])
