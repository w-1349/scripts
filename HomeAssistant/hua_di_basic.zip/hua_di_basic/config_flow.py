from __future__ import annotations

import voluptuous as vol
from aiohttp import ClientSession

from homeassistant import config_entries
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .api import HuaDiApi, HuaDiApiError
from .const import (
    CONF_ACCESS_KEY_ID, CONF_ACCESS_KEY_SECRET, CONF_DEVICE_ID, CONF_PHONE,
    CONF_PRODUCT_KEY, CONF_TOKEN,
    DEFAULT_ACCESS_KEY_ID, DEFAULT_ACCESS_KEY_SECRET, DEFAULT_NAME, DOMAIN,
)


class HuaDiConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Only App/mini-program SMS-code login is supported."""

    VERSION = 5

    def __init__(self) -> None:
        self._reauth_entry = None

    async def _login_and_discover(self, phone: str, code: str, name: str) -> tuple[dict, str, str]:
        session: ClientSession = async_get_clientsession(self.hass)
        api = HuaDiApi(session, {"SOURCE": "0"})
        login_data = await api.async_login_code(phone, code)
        token = login_data["accessToken"]
        device, family = await api.async_discover_first_water_heater(token)
        device_id = device.get("id") or device.get("deviceId")
        product_key = device.get("productKey")
        if not device_id or not product_key:
            raise HuaDiApiError("登录成功，但没有找到 deviceId/productKey")

        device_name = str(device.get("deviceName") or device.get("nickname") or device.get("name") or name)
        data = {
            "name": name,
            CONF_PHONE: phone,
            CONF_TOKEN: token,
            CONF_ACCESS_KEY_ID: DEFAULT_ACCESS_KEY_ID,
            CONF_ACCESS_KEY_SECRET: DEFAULT_ACCESS_KEY_SECRET,
            CONF_DEVICE_ID: str(device_id),
            CONF_PRODUCT_KEY: str(product_key),
            "family_id": (family or {}).get("familyId") or device.get("familyId"),
            "device_name": device.get("deviceName") or device.get("nickname") or device.get("name"),
            "SOURCE": "0",
            "PLATFORM": "",
            "REFERER": "",
            "SIGN_TRAILING_AMP": "1",
            "USER_AGENT": "hua di zhi hui jia/5.1.6 (iPhone; iOS 26.4; Scale/3.00)",
            "PRIORITY": "u=3, i",
            "ACCEPT_LANGUAGE": "zh-Hans-CN;q=1",
        }
        return data, device_name, str(device_id)

    async def async_step_user(self, user_input=None):
        return await self.async_step_sms(user_input)

    async def async_step_sms(self, user_input=None):
        errors: dict[str, str] = {}
        if user_input is not None:
            phone = user_input[CONF_PHONE].strip()
            code = user_input["verification_code"].strip()
            name = user_input.get("name", DEFAULT_NAME)
            try:
                data, device_name, device_id = await self._login_and_discover(phone, code, name)
            except HuaDiApiError:
                errors["base"] = "login_failed"
            else:
                await self.async_set_unique_id(device_id)
                self._abort_if_unique_id_configured()
                return self.async_create_entry(title=name or device_name, data=data)

        schema = vol.Schema({
            vol.Required("name", default=DEFAULT_NAME): str,
            vol.Required(CONF_PHONE): str,
            vol.Required("verification_code"): str,
        })
        return self.async_show_form(
            step_id="sms",
            data_schema=schema,
            errors=errors,
            description_placeholders={"tip": "请先在华帝 App/小程序中发送短信验证码，再把验证码填到这里。"},
        )

    async def async_step_reauth(self, entry_data):
        self._reauth_entry = self.hass.config_entries.async_get_entry(self.context["entry_id"])
        return await self.async_step_reauth_sms()

    async def async_step_reauth_sms(self, user_input=None):
        entry = self._reauth_entry
        if entry is None:
            return self.async_abort(reason="reauth_failed")
        errors: dict[str, str] = {}
        old_data = dict(entry.data)
        if user_input is not None:
            phone = user_input[CONF_PHONE].strip()
            code = user_input["verification_code"].strip()
            name = user_input.get("name", entry.title or DEFAULT_NAME)
            try:
                data, _device_name, _device_id = await self._login_and_discover(phone, code, name)
            except HuaDiApiError:
                errors["base"] = "login_failed"
            else:
                old_data.update(data)
                self.hass.config_entries.async_update_entry(entry, title=name, data=old_data)
                return self.async_abort(reason="reauth_successful")

        schema = vol.Schema({
            vol.Required("name", default=entry.title or DEFAULT_NAME): str,
            vol.Required(CONF_PHONE, default=old_data.get(CONF_PHONE, "")): str,
            vol.Required("verification_code"): str,
        })
        return self.async_show_form(
            step_id="reauth_sms",
            data_schema=schema,
            errors=errors,
            description_placeholders={"tip": "请先在华帝 App/小程序中发送短信验证码。"},
        )
