from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any

from aiohttp import ClientSession

from .const import (
    CONF_ACCESS_KEY_ID,
    CONF_ACCESS_KEY_SECRET,
    CONF_ACW_TC,
    CONF_DEVICE_ID,
    CONF_ENV_PATH,
    CONF_PRODUCT_KEY,
    CONF_TOKEN,
    DEFAULT_ACCESS_KEY_ID,
    DEFAULT_ACCESS_KEY_SECRET,
    ECM_ACCESS_KEY_ID,
    ECM_ACCESS_KEY_SECRET,
)


class HuaDiApiError(Exception):
    """HuaDi API error."""


class HuaDiAuthError(HuaDiApiError):
    """HuaDi token/authentication expired."""


def normalize_temp(value: int) -> int:
    if value < 35:
        return 35
    if value <= 50:
        return value
    if 51 <= value <= 54:
        return 55
    if value == 55:
        return 55
    if 56 <= value <= 59:
        return 60
    return 60


def to_int(value: Any) -> int | None:
    try:
        if value is None:
            return None
        if isinstance(value, str) and value.strip() in ("", "unknown", "unavailable", "none", "None"):
            return None
        return int(float(value))
    except (TypeError, ValueError):
        return None


class HuaDiApi:
    BASE_URL = "https://api.vcoo.cloud"
    LOGIN_CODE_URL = f"{BASE_URL}/api/app/v1/user/login/code"
    FAMILY_LIST_URL = f"{BASE_URL}/api/app/v1/family/list"
    DEVICE_LIST_URL = f"{BASE_URL}/api/app/v1/device/list"
    RRPC_URL = f"{BASE_URL}/api/app/v1/device/rrpc"
    ECM_WATER_GAS_LIST_URL = f"{BASE_URL}/ecm/getOldYearWaterGasList"

    def __init__(self, session: ClientSession, config: dict[str, Any] | str, timeout: int = 15) -> None:
        self.session = session
        self.timeout = timeout

        if isinstance(config, str):
            self._config: dict[str, Any] = {CONF_ENV_PATH: config}
        else:
            self._config = dict(config)

        self.env_path = self.resolve_env_path(self._config.get("env_path", "")) if self._config.get("env_path") else None
        self._env: dict[str, str] = {}
        self._env_mtime: float | None = None

    @staticmethod
    def resolve_env_path(env_path: str) -> Path:
        path = Path(env_path)
        if path.exists():
            return path

        text = str(path)
        if text.startswith("/homeassistant/"):
            alt = Path("/config") / text.removeprefix("/homeassistant/")
            if alt.exists():
                return alt

        if text.startswith("/config/"):
            alt = Path("/homeassistant") / text.removeprefix("/config/")
            if alt.exists():
                return alt

        return path

    def _env_from_entry_data(self) -> dict[str, str]:
        token = self._config.get(CONF_TOKEN) or self._config.get("TOKEN")
        device_id = self._config.get(CONF_DEVICE_ID) or self._config.get("DEVICE_ID")
        product_key = self._config.get(CONF_PRODUCT_KEY) or self._config.get("PRODUCT_KEY")

        if not token and not device_id and not product_key:
            return {}

        return {
            "TOKEN": str(token or ""),
            "DEVICE_ID": str(device_id or ""),
            "PRODUCT_KEY": str(product_key or ""),
            "ACCESS_KEY_ID": str(self._config.get(CONF_ACCESS_KEY_ID) or self._config.get("ACCESS_KEY_ID") or DEFAULT_ACCESS_KEY_ID),
            "APP_ACCESS_KEY_SECRET": str(self._config.get(CONF_ACCESS_KEY_SECRET) or self._config.get("APP_ACCESS_KEY_SECRET") or DEFAULT_ACCESS_KEY_SECRET),
            "ACW_TC": str(self._config.get(CONF_ACW_TC) or self._config.get("ACW_TC") or ""),
            "APP_VERSION": str(self._config.get("APP_VERSION") or "5.1.6"),
            "USER_AGENT": str(self._config.get("USER_AGENT") or "hua di zhi hui jia/5.1.6 (iPhone; iOS 26.4; Scale/3.00)"),
            "HOST": str(self._config.get("HOST") or "api.vcoo.cloud"),
            "PRIORITY": str(self._config.get("PRIORITY") or "u=3, i"),
            "ACCEPT_LANGUAGE": str(self._config.get("ACCEPT_LANGUAGE") or "zh-Hans-CN;q=1"),
            "ACCEPT_ENCODING": str(self._config.get("ACCEPT_ENCODING") or "gzip, deflate, br"),
            "SOURCE": str(self._config.get("SOURCE") or self._config.get("source") or "0"),
            "PLATFORM": str(self._config.get("PLATFORM") or self._config.get("platform") or ""),
            "REFERER": str(self._config.get("REFERER") or self._config.get("referer") or ""),
            "SIGN_TRAILING_AMP": str(self._config.get("SIGN_TRAILING_AMP") or self._config.get("sign_trailing_amp") or "1"),
        }

    def load_env(self, force: bool = False) -> dict[str, str]:
        entry_env = self._env_from_entry_data()
        if entry_env:
            self._env = entry_env
            return entry_env

        if not self.env_path:
            raise HuaDiApiError("No env_path or login data configured")

        try:
            mtime = self.env_path.stat().st_mtime
        except FileNotFoundError as exc:
            raise HuaDiApiError(f"Env file not found: {self.env_path}") from exc

        if not force and self._env and self._env_mtime == mtime:
            return self._env

        data: dict[str, str] = {}
        raw = self.env_path.read_text(encoding="utf-8", errors="ignore")
        for line in raw.splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            data[key.strip()] = value.strip().strip("'").strip('"')

        data.setdefault("ACCESS_KEY_ID", DEFAULT_ACCESS_KEY_ID)
        data.setdefault("APP_ACCESS_KEY_SECRET", DEFAULT_ACCESS_KEY_SECRET)
        data.setdefault("APP_VERSION", "5.1.6")
        data.setdefault("USER_AGENT", "hua di zhi hui jia/5.1.6 (iPhone; iOS 26.4; Scale/3.00)")
        data.setdefault("HOST", "api.vcoo.cloud")
        data.setdefault("PRIORITY", "u=3, i")
        data.setdefault("ACCEPT_LANGUAGE", "zh-Hans-CN;q=1")
        data.setdefault("ACCEPT_ENCODING", "gzip, deflate, br")
        data.setdefault("SOURCE", "0")
        data.setdefault("PLATFORM", "")
        data.setdefault("REFERER", "")
        data.setdefault("SIGN_TRAILING_AMP", "1")

        self._env = data
        self._env_mtime = mtime
        return data

    def validate_env(self) -> list[str]:
        env = self.load_env(force=True)
        required = ["TOKEN", "ACCESS_KEY_ID", "DEVICE_ID", "PRODUCT_KEY"]
        return [key for key in required if not env.get(key)]

    def _now_ms(self) -> str:
        return str(int(time.time() * 1000))

    def _calculate_sign(self, body: dict[str, Any], secret: str, *, trailing_amp: bool = True) -> str:
        pairs: list[str] = []
        for key in sorted(body.keys()):
            if not key or key == "sign":
                continue
            value = body.get(key)
            if value is None:
                continue
            value_str = str(value)
            if value_str == "":
                continue
            pairs.append(f"{key}={value_str}")
        raw = ("".join(f"{p}&" for p in pairs) if trailing_amp else "&".join(pairs)) + secret
        return hashlib.md5(raw.encode("utf-8")).hexdigest()

    def _make_headers(self, env: dict[str, str], timestamp: str, sign: str, token_override: str | None = None) -> dict[str, str]:
        token = token_override if token_override is not None else env.get("TOKEN", "")
        headers = {
            "host": env.get("HOST", "api.vcoo.cloud"),
            "content-type": "application/json",
            "accept": "application/json",
            "uid": token,
            "timestamp": timestamp,
            "version": env.get("APP_VERSION", "5.1.6"),
            "priority": env.get("PRIORITY", "u=3, i"),
            "accesskeyid": env.get("ACCESS_KEY_ID", DEFAULT_ACCESS_KEY_ID),
            "accept-language": env.get("ACCEPT_LANGUAGE", "zh-Hans-CN;q=1"),
            "accesstoken": token,
            "accept-encoding": env.get("ACCEPT_ENCODING", "gzip, deflate, br"),
            "user-agent": env.get("USER_AGENT", "hua di zhi hui jia/5.1.6 (iPhone; iOS 26.4; Scale/3.00)"),
            "ts": timestamp,
            "cookie": f"acw_tc={env.get('ACW_TC', '')}",
            "connection": "keep-alive",
            "sign": sign,
        }
        if str(env.get("SOURCE")) == "2":
            headers.update({
                "source": "2",
                "platform": env.get("PLATFORM") or "mp-weixin",
                "xweb_xhr": "1",
                "accept": "*/*",
                "referer": env.get("REFERER") or "https://servicewechat.com/wx04cddca696abb170/33/page-frame.html",
                "priority": env.get("PRIORITY", "u=1, i"),
            })
            if token:
                headers["authorization"] = f"Bearer {token}"
                headers["accesstoken"] = token
            else:
                headers.pop("authorization", None)
                headers.pop("accesstoken", None)
            headers.pop("uid", None)
            headers.pop("version", None)
            headers.pop("ts", None)
            if not env.get("ACW_TC"):
                headers.pop("cookie", None)
        return headers

    def _base_env(self, token: str = "") -> dict[str, str]:
        source = str(self._config.get("SOURCE") or self._config.get("source") or "0")
        if source == "2":
            return {
                "TOKEN": token,
                "ACCESS_KEY_ID": DEFAULT_ACCESS_KEY_ID,
                "APP_ACCESS_KEY_SECRET": DEFAULT_ACCESS_KEY_SECRET,
                "ACW_TC": str(self._config.get(CONF_ACW_TC) or self._config.get("ACW_TC") or ""),
                "APP_VERSION": "",
                "USER_AGENT": str(self._config.get("USER_AGENT") or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090a13) UnifiedPCWindowsWechat(0xf2541923) XWEB/19841"),
                "HOST": "api.vcoo.cloud",
                "PRIORITY": "u=1, i",
                "ACCEPT_LANGUAGE": "zh-CN,zh;q=0.9",
                "ACCEPT_ENCODING": "gzip, deflate, br",
                "SOURCE": "2",
                "PLATFORM": "mp-weixin",
                "REFERER": "https://servicewechat.com/wx04cddca696abb170/33/page-frame.html",
                "SIGN_TRAILING_AMP": "0",
            }
        return {
            "TOKEN": token,
            "ACCESS_KEY_ID": DEFAULT_ACCESS_KEY_ID,
            "APP_ACCESS_KEY_SECRET": DEFAULT_ACCESS_KEY_SECRET,
            "ACW_TC": str(self._config.get(CONF_ACW_TC) or self._config.get("ACW_TC") or ""),
            "APP_VERSION": "5.1.6",
            "USER_AGENT": "hua di zhi hui jia/5.1.6 (iPhone; iOS 26.4; Scale/3.00)",
            "HOST": "api.vcoo.cloud",
            "PRIORITY": "u=3, i",
            "ACCEPT_LANGUAGE": "zh-Hans-CN;q=1",
            "ACCEPT_ENCODING": "gzip, deflate, br",
            "SOURCE": "0",
            "PLATFORM": "",
            "REFERER": "",
            "SIGN_TRAILING_AMP": "1",
        }

    def _signed_headers_and_body(self, env: dict[str, str], body: dict[str, Any], token_override: str | None = None) -> tuple[dict[str, str], dict[str, Any]]:
        timestamp = self._now_ms()
        body = dict(body)
        body["accessKeyId"] = env.get("ACCESS_KEY_ID", DEFAULT_ACCESS_KEY_ID)
        body["timestamp"] = timestamp

        secret = env.get("APP_ACCESS_KEY_SECRET", DEFAULT_ACCESS_KEY_SECRET)
        trailing_amp = str(env.get("SIGN_TRAILING_AMP", "1")) != "0"
        sign = self._calculate_sign(body, secret, trailing_amp=trailing_amp)
        headers = self._make_headers(env, timestamp, sign, token_override=token_override)
        if str(env.get("SOURCE")) == "2":
            body["sign"] = sign
        return headers, body

    async def _post_json(self, url: str, headers: dict[str, str], body: dict[str, Any]) -> dict[str, Any]:
        payload = json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode("utf-8")

        async with self.session.post(
            url,
            data=payload,
            headers=headers,
            timeout=self.timeout,
        ) as response:
            text = await response.text()
            if response.status < 200 or response.status >= 300:
                raise HuaDiApiError(f"HTTP {response.status}: {text}")

        try:
            data = json.loads(text)
        except json.JSONDecodeError as exc:
            raise HuaDiApiError(f"Invalid JSON: {text}") from exc

        if not self._response_success(data):
            if self._is_auth_error(data):
                raise HuaDiAuthError(f"Authentication expired: {data}")
            raise HuaDiApiError(f"API error: {data}")

        return data

    def _response_success(self, data: dict[str, Any]) -> bool:
        success = data.get("success")
        if success is False:
            return False

        code = data.get("code")
        if code is None:
            code = data.get("errcode")
        if code is None:
            return True

        code_text = str(code)
        if code_text in ("0", "200", "0000", "SUCCESS", "success"):
            return True

        return False

    def _is_auth_error(self, data: dict[str, Any]) -> bool:
        code = data.get("code")
        if code is None:
            code = data.get("errcode")
        code_text = str(code) if code is not None else ""
        msg = str(data.get("msg") or data.get("message") or "")

        return (
            code_text in ("1003", "401", "403", "TOKEN_INVALID", "TOKEN_EXPIRED")
            or "TOKEN失效" in msg
            or "token失效" in msg
            or "token" in msg.lower() and ("expired" in msg.lower() or "invalid" in msg.lower())
        )

    async def async_login_code(self, phone: str, verification_code: str, sms_code: str = "86") -> dict[str, Any]:
        env = self._base_env()
        source = "2" if str(env.get("SOURCE")) == "2" else "0"
        body = {
            "phone": phone,
            "verificationCode": verification_code,
            "smsCode": sms_code,
            "source": 2 if source == "2" else "0",
        }
        headers, body = self._signed_headers_and_body(env, body, token_override="")
        data = await self._post_json(self.LOGIN_CODE_URL, headers, body)
        login_data = data.get("data") or {}
        token = login_data.get("accessToken")
        if not token:
            raise HuaDiApiError(f"Login succeeded but no accessToken returned: {data}")
        return login_data

    async def async_family_list_with_token(self, token: str) -> list[dict[str, Any]]:
        env = self._base_env(token)
        body = {"accessToken": token}
        headers, body = self._signed_headers_and_body(env, body)
        data = await self._post_json(self.FAMILY_LIST_URL, headers, body)
        families = data.get("data") or []
        if not isinstance(families, list):
            raise HuaDiApiError(f"Invalid family list: {data}")
        return families

    async def async_device_list_with_token(self, token: str, family_id: str) -> list[dict[str, Any]]:
        env = self._base_env(token)
        body = {
            "familyId": family_id,
            "currentPage": "1",
            "pageSize": "1000",
            "accessToken": token,
        }
        headers, body = self._signed_headers_and_body(env, body)
        data = await self._post_json(self.DEVICE_LIST_URL, headers, body)
        d = data.get("data") or {}
        devices = d.get("list") or []
        if not isinstance(devices, list):
            raise HuaDiApiError(f"Invalid device list: {data}")
        return devices

    async def async_discover_first_water_heater(self, token: str) -> tuple[dict[str, Any], dict[str, Any] | None]:
        families = await self.async_family_list_with_token(token)
        if not families:
            raise HuaDiApiError("No family found after login")

        first_device: dict[str, Any] | None = None
        chosen_family: dict[str, Any] | None = None

        for family in families:
            family_id = family.get("familyId") or family.get("id")
            if not family_id:
                continue
            devices = await self.async_device_list_with_token(token, str(family_id))
            for device in devices:
                text = json.dumps(device, ensure_ascii=False)
                if "热水器" in text or "i12571" in text or "i12572" in text:
                    return device, family
                if first_device is None:
                    first_device = device
                    chosen_family = family

        if first_device is None:
            raise HuaDiApiError("No device found after login")

        return first_device, chosen_family

    async def async_control_raw(self, msg: dict[str, Any]) -> dict[str, Any]:
        """Send a raw RRPC messageContent exactly as provided."""
        env = self.load_env()
        body = {
            "deviceId": env.get("DEVICE_ID", ""),
            "messageContent": json.dumps(msg, ensure_ascii=False, separators=(",", ":")),
            "accessToken": env.get("TOKEN", ""),
        }
        headers, body = self._signed_headers_and_body(env, body)
        return await self._post_json(self.RRPC_URL, headers, body)

    async def async_control(self, action: str, value: str | int | None = None) -> dict[str, Any]:
        """App-native RRPC controls captured from HuaDi App HAR."""
        if action == "temp":
            temp = normalize_temp(int(float(value)))
            # 手动调节任意有效温度档位都会退出预设温度模式：
            # 35-50、55、60 全部下发 tempMode=0。
            # 51-54 先按设备档位回跳为 55；56-59 先回跳为 60。
            # 60℃ 按抓包额外带 func_switch=2，同时仍带 tempMode=0 表示退出预设模式。
            if temp == 60:
                msg = {"heater_temp": "60", "tempMode": "0", "func_switch": "2"}
            else:
                msg = {"heater_temp": str(temp), "tempMode": "0"}
        elif action == "on":
            msg = {"powerStat": "1"}
        elif action == "off":
            # App 原生关机不是单发 powerStat=0，而是这个组合。
            msg = {"func_swit1": "0", "func_switch": "0", "powerStat": "0"}
        else:
            raise HuaDiApiError(f"Unknown action: {action}")

        return await self.async_control_raw(msg)

    def _ecm_signed_headers_and_body(self, body: dict[str, Any]) -> tuple[dict[str, str], dict[str, Any]]:
        """Sign H5 water/gas statistics requests.

        The H5 client can use a dedicated ECM key pair when one is supplied;
        otherwise the app pair is used for backward compatibility.  The
        signature algorithm is the same sorted key=value& + secret MD5.
        """
        env = self.load_env()
        # Dedicated ECM credentials can be supplied in entry/env data.  Fall
        # back to the app credentials for older entries that do not contain
        # them; this also keeps the integration importable across upgrades.
        ecm_access_key_id = str(self._config.get("ECM_ACCESS_KEY_ID") or env.get("ECM_ACCESS_KEY_ID") or ECM_ACCESS_KEY_ID)
        ecm_access_key_secret = str(self._config.get("ECM_ACCESS_KEY_SECRET") or env.get("ECM_ACCESS_KEY_SECRET") or ECM_ACCESS_KEY_SECRET)
        timestamp = self._now_ms()
        body = dict(body)
        body["timestamp"] = int(timestamp)
        body["accessKeyId"] = ecm_access_key_id
        body["accessToken"] = env.get("TOKEN", "")

        pieces: list[str] = []
        for key in sorted(body.keys()):
            if key == "sign":
                continue
            value = body.get(key)
            if value is None or str(value) == "":
                continue
            pieces.append(f"{key}={value}&")
        raw = "".join(pieces) + ecm_access_key_secret
        body["sign"] = hashlib.md5(raw.encode("utf-8")).hexdigest()

        headers = {
            "host": "api.vcoo.cloud",
            "content-type": "application/json",
            "accept": "application/json, text/plain, */*",
            "accessToken": env.get("TOKEN", ""),
            "user-agent": env.get("USER_AGENT", "hua di zhi hui jia/5.1.6 (iPhone; iOS 26.4; Scale/3.00)"),
            "accept-language": env.get("ACCEPT_LANGUAGE", "zh-Hans-CN;q=1"),
            "accesskeyid": ecm_access_key_id,
        }
        return headers, body

    def _parse_embedded_json_data(self, data: dict[str, Any]) -> Any:
        raw = data.get("data")
        if isinstance(raw, str):
            try:
                return json.loads(raw)
            except json.JSONDecodeError:
                return raw
        return raw

    async def async_get_water_gas_list(self, energy_type: str, time_unit: str) -> list[dict[str, Any]]:
        headers, body = self._ecm_signed_headers_and_body({
            "deviceId": self.load_env().get("DEVICE_ID", ""),
            "energyType": str(energy_type),
            "timeUnit": str(time_unit),
        })
        data = await self._post_json(self.ECM_WATER_GAS_LIST_URL, headers, body)
        parsed = self._parse_embedded_json_data(data)
        return parsed if isinstance(parsed, list) else []

    async def async_get_water_gas_statistics(self) -> dict[str, Any]:
        """Fetch only the two retained current-month totals."""
        water_month_list = await self.async_get_water_gas_list("0", "1")
        gas_month_list = await self.async_get_water_gas_list("2", "1")

        def latest_value(rows: list[dict[str, Any]]) -> float | None:
            if not rows:
                return None
            try:
                return round(float(rows[-1].get("value")), 2)
            except (TypeError, ValueError, AttributeError):
                return None

        stats = {
            "water_month": latest_value(water_month_list),
            "gas_month": latest_value(gas_month_list),
        }
        stats["stats_updated_at"] = int(time.time())
        return stats

