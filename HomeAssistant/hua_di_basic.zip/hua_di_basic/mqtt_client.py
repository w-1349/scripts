from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import random
import time
from typing import Any, Callable

import paho.mqtt.client as mqtt

_LOGGER = logging.getLogger(__name__)


MQTT_HOST = "post-cn-n6w2166d50a.mqtt.aliyuncs.com"
MQTT_PORT = 80
MQTT_TOPIC_PREFIX = "deviceProperty"
MQTT_CLIENT_ID_PREFIX = "GID_HYBRID_DEVICE_TOPIC_PRO@@@"
MQTT_USERNAME_PREFIX = "Signature|LTAI5tQAwr9fjF79sP34JEdk|"
MQTT_SECRET_KEY = "o4Z2x4pYgjeMKZZelXFSeSc3Yq0Ykm"
MQTT_INSTANCE_ID = "post-cn-n6w2166d50a"


def _coerce_value(value: Any) -> Any:
    if isinstance(value, dict):
        if "value" in value:
            return _coerce_value(value["value"])
        return {k: _coerce_value(v) for k, v in value.items()}

    if isinstance(value, list):
        return [_coerce_value(v) for v in value]

    if isinstance(value, str):
        text = value.strip()
        if text == "":
            return value
        try:
            if "." in text:
                return float(text)
            return int(text)
        except ValueError:
            return value

    return value


def _mask_value(value: str, keep: int = 4) -> str:
    value = str(value or "")
    if not value:
        return ""
    if len(value) <= keep:
        return "*" * len(value)
    return f"****{value[-keep:]}"


def _mask_topic(topic: str) -> str:
    parts = str(topic or "").split("/")
    if len(parts) >= 3:
        parts[-1] = _mask_value(parts[-1])
        parts[-2] = _mask_value(parts[-2])
    return "/".join(parts)


def normalize_mqtt_payload(payload: dict[str, Any]) -> dict[str, Any]:
    """Normalize App MQTT payload into HA coordinator data."""

    result: dict[str, Any] = {}

    items = payload.get("items")
    if isinstance(items, dict):
        for key, value in items.items():
            result[key] = _coerce_value(value)

    status = payload.get("status")
    if status is not None:
        text = str(status).lower()
        if text == "offline":
            result["online_status"] = 2
        elif text == "online":
            result["online_status"] = 1
        else:
            result["online_status"] = status

    # App/older cloud names compatibility
    if "all_water_flow" in result and "total_water" not in result:
        result["total_water"] = result["all_water_flow"]

    return result


class HuaDiAppMqttClient:
    """App-native Aliyun MQTT device property push channel.

    This follows the React Native code found in the HuaDi app:

    topic:
        deviceProperty/{deviceId}/{phone}

    clientId:
        GID_HYBRID_DEVICE_TOPIC_PRO@@@ + timestamp(ms) + random digits

    username:
        Signature|AccessKey|InstanceId

    password:
        Base64(HmacSHA1(clientId, secretKey))
    """

    def __init__(
        self,
        *,
        device_id: str,
        phone: str,
        on_payload: Callable[[dict[str, Any]], None],
        on_connected: Callable[[bool, str | None], None] | None = None,
    ) -> None:
        self.device_id = device_id
        self.phone = phone
        self.on_payload = on_payload
        self.on_connected = on_connected

        self.topic = f"{MQTT_TOPIC_PREFIX}/{device_id}/{phone}"
        self.client_id = f"{MQTT_CLIENT_ID_PREFIX}{int(time.time() * 1000)}{random.randint(10**9, 10**10 - 1)}"

        password = base64.b64encode(
            hmac.new(
                MQTT_SECRET_KEY.encode("utf-8"),
                self.client_id.encode("utf-8"),
                hashlib.sha1,
            ).digest()
        ).decode("utf-8")

        username = f"{MQTT_USERNAME_PREFIX}{MQTT_INSTANCE_ID}"

        try:
            self.client = mqtt.Client(
                client_id=self.client_id,
                clean_session=True,
                transport="websockets",
            )
        except TypeError:
            # paho-mqtt 2.x compatibility fallback
            self.client = mqtt.Client(
                client_id=self.client_id,
                transport="websockets",
            )
        self.client.ws_set_options(path="/mqtt")
        self.client.username_pw_set(username=username, password=password)
        self.client.reconnect_delay_set(min_delay=1, max_delay=30)

        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.on_message = self._on_message

    def start(self) -> None:
        _LOGGER.info("Starting HuaDi App MQTT: host=%s port=%s topic=%s client_id=%s", MQTT_HOST, MQTT_PORT, _mask_topic(self.topic), _mask_value(self.client_id, 6))
        self.client.connect_async(MQTT_HOST, MQTT_PORT, keepalive=10)
        self.client.loop_start()

    def stop(self) -> None:
        try:
            self.client.loop_stop()
            self.client.disconnect()
        except Exception as exc:  # noqa: BLE001
            _LOGGER.debug("Stopping HuaDi MQTT failed: %s", exc)

    def _on_connect(self, client, userdata, flags, rc) -> None:
        if rc == 0:
            _LOGGER.info("HuaDi App MQTT connected, subscribing %s", _mask_topic(self.topic))
            client.subscribe(self.topic)
            if self.on_connected:
                self.on_connected(True, None)
        else:
            _LOGGER.warning("HuaDi App MQTT connect failed rc=%s", rc)
            if self.on_connected:
                self.on_connected(False, f"connect_rc_{rc}")

    def _on_disconnect(self, client, userdata, rc) -> None:
        _LOGGER.warning("HuaDi App MQTT disconnected rc=%s", rc)
        if self.on_connected:
            self.on_connected(False, f"disconnect_rc_{rc}")

    def _on_message(self, client, userdata, message) -> None:
        try:
            text = message.payload.decode("utf-8", errors="ignore")
            payload = json.loads(text)
            if not isinstance(payload, dict):
                return

            data = normalize_mqtt_payload(payload)
            _LOGGER.debug("HuaDi App MQTT message received, keys=%s", sorted(data.keys()))
            if data:
                self.on_payload(data)
        except Exception as exc:  # noqa: BLE001
            _LOGGER.warning("Failed to process HuaDi MQTT message: %s", exc)
